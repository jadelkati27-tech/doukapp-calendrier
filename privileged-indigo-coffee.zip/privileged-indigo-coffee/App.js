import React, { useState } from 'react';
import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
  ScrollView,
  Modal,
  TextInput,
  SafeAreaView,
  StatusBar
} from 'react-native';

const DAYS_SHORT = ['Dim', 'Lun', 'Mar', 'Mer', 'Jeu', 'Ven', 'Sam'];
const MONTHS = [
  'Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin',
  'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre'
];

export default function App() {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedDay, setSelectedDay] = useState(13);
  const [events, setEvents] = useState({
    [`${new Date().getFullYear()}-${new Date().getMonth() + 1}-13`]: [
      'Réunion projet DoukApp 🚀',
      'Review du design 🎨'
    ]
  });
  const [modalVisible, setModalVisible] = useState(false);
  const [newEvent, setNewEvent] = useState('');

  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();

  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const firstDayIndex = new Date(year, month, 1).getDay();

  const dateKey = `${year}-${month + 1}-${selectedDay}`;

  const handlePrevMonth = () => {
    setCurrentDate(new Date(year, month - 1, 1));
  };

  const handleNextMonth = () => {
    setCurrentDate(new Date(year, month + 1, 1));
  };

  const addEvent = () => {
    if (!newEvent.trim()) return;
    const currentList = events[dateKey] || [];
    setEvents({
      ...events,
      [dateKey]: [...currentList, newEvent]
    });
    setNewEvent('');
    setModalVisible(false);
  };

  const calendarGrid = [];
  for (let i = 0; i < firstDayIndex; i++) {
    calendarGrid.push(null);
  }
  for (let d = 1; d <= daysInMonth; d++) {
    calendarGrid.push(d);
  }

  return (
    <SafeAreaView style={styles.safeArea}>
      <StatusBar barStyle="light-content" backgroundColor="#35BDCE" />

      {/* Header Bar */}
      <View style={styles.headerBar}>
        <View style={styles.brandingContainer}>
          <View style={styles.logoBadge}>
            <Text style={styles.logoBadgeText}>{new Date().getDate()}</Text>
          </View>
          <View>
            <Text style={styles.appName}>Calendrier</Text>
            <Text style={styles.appSubName}>DoukApp</Text>
          </View>
        </View>

        {/* Month Navigation */}
        <View style={styles.monthNav}>
          <TouchableOpacity onPress={handlePrevMonth} style={styles.navArrow}>
            <Text style={styles.navArrowText}>‹</Text>
          </TouchableOpacity>
          <Text style={styles.monthTitle}>{MONTHS[month]} {year}</Text>
          <TouchableOpacity onPress={handleNextMonth} style={styles.navArrow}>
            <Text style={styles.navArrowText}>›</Text>
          </TouchableOpacity>
        </View>
      </View>

      <View style={styles.bodyContainer}>
        {/* Days of Week Header */}
        <View style={styles.weekHeader}>
          {DAYS_SHORT.map((d, index) => (
            <Text key={index} style={styles.weekDayLabel}>{d}</Text>
          ))}
        </View>

        {/* Days Grid */}
        <View style={styles.grid}>
          {calendarGrid.map((day, index) => {
            const isSelected = day === selectedDay;
            const hasEvents = day && events[`${year}-${month + 1}-${day}`]?.length > 0;

            return (
              <TouchableOpacity
                key={index}
                disabled={!day}
                style={[
                  styles.dayBox,
                  isSelected && styles.selectedDayBox,
                  !day && styles.emptyBox
                ]}
                onPress={() => day && setSelectedDay(day)}
              >
                {day && (
                  <>
                    <Text style={[styles.dayNumber, isSelected && styles.selectedDayNumber]}>
                      {day}
                    </Text>
                    {hasEvents && !isSelected && <View style={styles.eventDot} />}
                  </>
                )}
              </TouchableOpacity>
            );
          })}
        </View>

        {/* Event List Section */}
        <View style={styles.eventSection}>
          <View style={styles.eventHeader}>
            <View style={styles.titleWithBadge}>
              <View style={styles.selectedBadge}>
                <Text style={styles.selectedBadgeText}>{selectedDay}</Text>
              </View>
              <Text style={styles.eventSectionTitle}>
                {selectedDay} {MONTHS[month]}
              </Text>
            </View>
            <TouchableOpacity style={styles.addBtn} onPress={() => setModalVisible(true)}>
              <Text style={styles.addBtnText}>+ Ajouter</Text>
            </TouchableOpacity>
          </View>

          <ScrollView style={styles.eventList} showsVerticalScrollIndicator={false}>
            {events[dateKey] && events[dateKey].length > 0 ? (
              events[dateKey].map((item, idx) => (
                <View key={idx} style={styles.eventCard}>
                  <View style={styles.eventCardIndicator} />
                  <Text style={styles.eventText}>{item}</Text>
                </View>
              ))
            ) : (
              <View style={styles.emptyState}>
                <Text style={styles.emptyStateText}>Aucun événement pour cette date</Text>
              </View>
            )}
          </ScrollView>
        </View>
      </View>

      {/* Add Event Modal */}
      <Modal visible={modalVisible} transparent animationType="slide">
        <View style={styles.modalBackdrop}>
          <View style={styles.modalCard}>
            <Text style={styles.modalTitle}>Nouvel Événement</Text>
            <TextInput
              style={styles.modalInput}
              placeholder="Saisir une note ou tâche..."
              placeholderTextColor="#94A3B8"
              value={newEvent}
              onChangeText={setNewEvent}
            />
            <View style={styles.modalButtons}>
              <TouchableOpacity style={styles.cancelButton} onPress={() => setModalVisible(false)}>
                <Text style={styles.cancelText}>Annuler</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.saveButton} onPress={addEvent}>
                <Text style={styles.saveText}>Enregistrer</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: '#35BDCE' },
  headerBar: { paddingHorizontal: 20, paddingTop: 15, paddingBottom: 20, backgroundColor: '#35BDCE' },
  brandingContainer: { flexDirection: 'row', alignItems: 'center', marginBottom: 15 },
  logoBadge: { width: 38, height: 38, backgroundColor: '#FFFFFF', borderRadius: 12, justifyContent: 'center', alignItems: 'center', marginRight: 12 },
  logoBadgeText: { color: '#35BDCE', fontSize: 18, fontWeight: '800' },
  appName: { color: '#FFFFFF', fontSize: 20, fontWeight: 'bold' },
  appSubName: { color: 'rgba(255, 255, 255, 0.8)', fontSize: 12 },
  monthNav: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', backgroundColor: 'rgba(255, 255, 255, 0.2)', borderRadius: 16, paddingHorizontal: 15, paddingVertical: 8 },
  monthTitle: { color: '#FFFFFF', fontSize: 16, fontWeight: 'bold' },
  navArrow: { paddingHorizontal: 10 },
  navArrowText: { color: '#FFFFFF', fontSize: 24, fontWeight: 'bold' },
  bodyContainer: { flex: 1, backgroundColor: '#F8FAFC', borderTopLeftRadius: 28, borderTopRightRadius: 28, paddingHorizontal: 16, paddingTop: 20 },
  weekHeader: { flexDirection: 'row', justifyContent: 'space-between', marginBottom: 10, paddingHorizontal: 5 },
  weekDayLabel: { width: '14%', textAlign: 'center', color: '#64748B', fontWeight: '700', fontSize: 13 },
  grid: { flexDirection: 'row', flexWrap: 'wrap' },
  dayBox: { width: '14%', height: 44, justifyContent: 'center', alignItems: 'center', marginVertical: 3, borderRadius: 14 },
  selectedDayBox: { backgroundColor: '#35BDCE', shadowColor: '#35BDCE', shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.3, shadowRadius: 6, elevation: 4 },
  emptyBox: { backgroundColor: 'transparent' },
  dayNumber: { fontSize: 15, fontWeight: '600', color: '#334155' },
  selectedDayNumber: { color: '#FFFFFF', fontWeight: 'bold', fontSize: 17 },
  eventDot: { width: 4, height: 4, borderRadius: 2, backgroundColor: '#35BDCE', marginTop: 2 },
  eventSection: { flex: 1, marginTop: 15, backgroundColor: '#FFFFFF', borderRadius: 20, padding: 16 },
  eventHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 },
  titleWithBadge: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  selectedBadge: { width: 30, height: 30, borderRadius: 10, backgroundColor: '#E6F8FA', justifyContent: 'center', alignItems: 'center' },
  selectedBadgeText: { color: '#35BDCE', fontWeight: 'bold' },
  eventSectionTitle: { fontSize: 15, fontWeight: 'bold', color: '#1E293B' },
  addBtn: { backgroundColor: '#35BDCE', paddingHorizontal: 12, paddingVertical: 6, borderRadius: 12 },
  addBtnText: { color: '#FFFFFF', fontSize: 12, fontWeight: 'bold' },
  eventList: { flex: 1 },
  eventCard: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#F1F5F9', padding: 12, borderRadius: 12, marginBottom: 8 },
  eventCardIndicator: { width: 4, height: 16, backgroundColor: '#35BDCE', borderRadius: 2, marginRight: 10 },
  eventText: { color: '#334155', fontSize: 14, flex: 1, textAlign: 'left' },
  emptyState: { paddingVertical: 30, alignItems: 'center' },
  emptyStateText: { color: '#94A3B8', fontSize: 13 },
  modalBackdrop: { flex: 1, backgroundColor: 'rgba(15, 23, 42, 0.5)', justifyContent: 'center', alignItems: 'center' },
  modalCard: { width: '85%', backgroundColor: '#FFFFFF', borderRadius: 20, padding: 20 },
  modalTitle: { fontSize: 16, fontWeight: 'bold', color: '#1E293B', marginBottom: 12, textAlign: 'left' },
  modalInput: { backgroundColor: '#F8FAFC', borderWidth: 1, borderColor: '#E2E8F0', borderRadius: 12, padding: 12, textAlign: 'left', color: '#0F172A', marginBottom: 16 },
  modalButtons: { flexDirection: 'row', justifyContent: 'flex-end', gap: 10 },
  cancelButton: { paddingHorizontal: 16, paddingVertical: 8, borderRadius: 10, backgroundColor: '#F1F5F9' },
  cancelText: { color: '#64748B', fontWeight: '600' },
  saveButton: { paddingHorizontal: 20, paddingVertical: 8, borderRadius: 10, backgroundColor: '#35BDCE' },
  saveText: { color: '#FFFFFF', fontWeight: 'bold' }
});